// Exam JavaScript functionality

// Use window variables if they exist, otherwise initialize
let currentQuestion = window.currentQuestion || 0;
let totalQuestions = window.totalQuestions || 0;
let examTimer = null;
let timeRemaining = 0;
let examQuestions = window.examQuestions || [];
let attemptId = window.attemptId;

// Initialize exam
function initializeExam(questions, minutes) {
    totalQuestions = questions;
    timeRemaining = minutes * 60; // Convert to seconds
    startTimer();
    updateQuestionNavigation();
}

// Timer functionality
function startTimer(minutes) {
    timeRemaining = minutes * 60; // Convert to seconds
    examTimer = setInterval(updateTimer, 1000);
    updateTimer(); // Update immediately
}

function updateTimer() {
    if (timeRemaining <= 0) {
        clearInterval(examTimer);
        // Auto-submit exam when time is up
        alert('Time is up! Your exam will be submitted automatically.');
        window.location.href = `/submit_exam/${attemptId}`;
        return;
    }
    
    const hours = Math.floor(timeRemaining / 3600);
    const minutes = Math.floor((timeRemaining % 3600) / 60);
    const seconds = timeRemaining % 60;
    
    let timeDisplay = '';
    if (hours > 0) {
        timeDisplay = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    } else {
        timeDisplay = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
    
    const timerElement = document.getElementById('time-remaining');
    if (timerElement) {
        timerElement.textContent = timeDisplay;
        
        // Add warning class when less than 5 minutes remain
        if (timeRemaining <= 300) { // 5 minutes
            timerElement.classList.add('timer-warning');
        }
        
        // Add critical class when less than 1 minute remains
        if (timeRemaining <= 60) { // 1 minute
            timerElement.classList.add('timer-critical');
        }
    }
    
    timeRemaining--;
}

// Question navigation
function showQuestion(questionIndex) {
    // Hide all questions
    document.querySelectorAll('.question-content').forEach(q => {
        q.style.display = 'none';
    });
    
    // Show selected question
    const questionElement = document.getElementById(`question-${questionIndex}`);
    if (questionElement) {
        questionElement.style.display = 'block';
        currentQuestion = questionIndex;
        updateQuestionNavigation();
        updateNavigationButtons();
    }
}

function nextQuestion() {
    if (currentQuestion < totalQuestions - 1) {
        showQuestion(currentQuestion + 1);
    }
}

function previousQuestion() {
    if (currentQuestion > 0) {
        showQuestion(currentQuestion - 1);
    }
}

function updateNavigationButtons() {
    const prevBtn = document.querySelector('[onclick="previousQuestion()"]');
    const nextBtn = document.querySelector('[onclick="nextQuestion()"]');
    
    if (prevBtn) {
        prevBtn.disabled = currentQuestion === 0;
    }
    
    if (nextBtn) {
        nextBtn.disabled = currentQuestion === totalQuestions - 1;
    }
}

function updateQuestionNavigation() {
    // Update question number buttons
    document.querySelectorAll('.question-number').forEach((btn, index) => {
        btn.classList.remove('current', 'answered', 'unanswered');
        
        if (index === currentQuestion) {
            btn.classList.add('current');
        } else {
            // Check if question is answered
            const questionId = examQuestions[index];
            const answeredInput = document.querySelector(`input[name="question_${questionId}"]:checked`);
            
            if (answeredInput) {
                btn.classList.add('answered');
            } else {
                btn.classList.add('unanswered');
            }
        }
    });
}

// Save answer functionality
function saveAnswer(attemptId, questionId, selectedAnswer) {
    // Validate inputs
    if (!attemptId || !questionId) {
        console.error('Missing attempt ID or question ID');
        return;
    }
    
    // Create form data
    const formData = new FormData();
    formData.append('attempt_id', attemptId);
    formData.append('question_id', questionId);
    formData.append('selected_answer', selectedAnswer || '');
    
    // Send AJAX request
    fetch('/save_answer', {
        method: 'POST',
        body: formData,
        credentials: 'same-origin' // Include session cookie
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            // Update question navigation to show answered status
            updateQuestionNavigation();
            
            // Show brief success feedback (only for non-empty answers)
            if (selectedAnswer) {
                showFeedback('Answer saved', 'success');
            }
        } else {
            console.error('Save failed:', data.error);
            showFeedback(`Failed to save: ${data.error || 'Unknown error'}`, 'error');
        }
    })
    .catch(error => {
        console.error('Error saving answer:', error);
        showFeedback('Error saving answer', 'error');
    });
}

function clearAnswer(questionId) {
    // Clear radio button selection
    const radioButtons = document.querySelectorAll(`input[name="question_${questionId}"]`);
    radioButtons.forEach(radio => {
        radio.checked = false;
    });
    
    // Save empty answer
    if (attemptId) {
        saveAnswer(attemptId, questionId, '');
    }
    
    updateQuestionNavigation();
    showFeedback('Answer cleared', 'info');
}

// Submit exam functionality
function submitExam() {
    // Calculate submission summary
    let answered = 0;
    let unanswered = 0;
    
    examQuestions.forEach(questionId => {
        const answeredInput = document.querySelector(`input[name="question_${questionId}"]:checked`);
        if (answeredInput) {
            answered++;
        } else {
            unanswered++;
        }
    });
    
    // Update modal content
    const summaryElement = document.getElementById('submission-summary');
    if (summaryElement) {
        summaryElement.innerHTML = `
            <div class="row text-center">
                <div class="col-4">
                    <div class="badge bg-success fs-6">${answered}</div>
                    <div class="small text-muted">Answered</div>
                </div>
                <div class="col-4">
                    <div class="badge bg-warning fs-6">${unanswered}</div>
                    <div class="small text-muted">Unanswered</div>
                </div>
                <div class="col-4">
                    <div class="badge bg-primary fs-6">${totalQuestions}</div>
                    <div class="small text-muted">Total</div>
                </div>
            </div>
        `;
    }
    
    // Show confirmation modal
    const submitModal = new bootstrap.Modal(document.getElementById('submitModal'));
    submitModal.show();
}

// Utility functions
function showFeedback(message, type) {
    // Create toast notification
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type === 'success' ? 'success' : type === 'error' ? 'danger' : 'info'} border-0`;
    toast.setAttribute('role', 'alert');
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                <i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'exclamation-triangle' : 'info-circle'} me-2"></i>
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    
    // Add to page
    let toastContainer = document.getElementById('toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'toast-container';
        toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
        toastContainer.style.zIndex = '1055';
        document.body.appendChild(toastContainer);
    }
    
    toastContainer.appendChild(toast);
    
    // Show toast
    const bsToast = new bootstrap.Toast(toast, { delay: 2000 });
    bsToast.show();
    
    // Remove toast after it's hidden
    toast.addEventListener('hidden.bs.toast', () => {
        toast.remove();
    });
}

// Keyboard shortcuts
document.addEventListener('keydown', function(event) {
    // Prevent accidental page refresh/navigation
    if (event.key === 'F5' || (event.ctrlKey && event.key === 'r')) {
        event.preventDefault();
        showFeedback('Page refresh is disabled during exam', 'info');
        return;
    }
    
    // Arrow key navigation
    if (event.key === 'ArrowLeft') {
        event.preventDefault();
        previousQuestion();
    } else if (event.key === 'ArrowRight') {
        event.preventDefault();
        nextQuestion();
    }
    
    // Number key navigation (1-9)
    if (event.key >= '1' && event.key <= '9') {
        const questionIndex = parseInt(event.key) - 1;
        if (questionIndex < totalQuestions) {
            event.preventDefault();
            showQuestion(questionIndex);
        }
    }
});

// Prevent right-click context menu
document.addEventListener('contextmenu', function(event) {
    event.preventDefault();
    showFeedback('Right-click is disabled during exam', 'info');
});

// Warn before leaving page
window.addEventListener('beforeunload', function(event) {
    if (examTimer) {
        event.preventDefault();
        event.returnValue = 'Are you sure you want to leave? Your exam progress will be lost.';
        return event.returnValue;
    }
});

// Auto-save functionality
let autoSaveInterval;

function startAutoSave() {
    // Auto-save every 30 seconds
    autoSaveInterval = setInterval(() => {
        // This is a backup save - individual answers are already saved immediately
        console.log('Auto-save checkpoint');
    }, 30000);
}

function stopAutoSave() {
    if (autoSaveInterval) {
        clearInterval(autoSaveInterval);
    }
}

// Initialize auto-save when page loads
document.addEventListener('DOMContentLoaded', function() {
    if (document.querySelector('.question-content')) {
        startAutoSave();
    }
});

// Focus management
function focusCurrentQuestion() {
    const currentQuestionElement = document.getElementById(`question-${currentQuestion}`);
    if (currentQuestionElement) {
        currentQuestionElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

// Mobile responsiveness
function handleMobileView() {
    if (window.innerWidth < 768) {
        // Adjust question navigation for mobile
        const questionNav = document.querySelector('.question-nav');
        if (questionNav) {
            questionNav.style.maxHeight = '200px';
        }
    }
}

// Initialize mobile handling
window.addEventListener('resize', handleMobileView);
document.addEventListener('DOMContentLoaded', handleMobileView);

// Exam completion tracking
function trackExamProgress() {
    const answered = document.querySelectorAll('input[type="radio"]:checked').length;
    const progress = (answered / totalQuestions) * 100;
    
    // Update progress if there's a progress bar
    const progressBar = document.querySelector('.exam-progress');
    if (progressBar) {
        progressBar.style.width = `${progress}%`;
        progressBar.setAttribute('aria-valuenow', progress);
    }
    
    return {
        answered: answered,
        total: totalQuestions,
        percentage: progress
    };
}

// Call progress tracking when answers change
document.addEventListener('change', function(event) {
    if (event.target.type === 'radio') {
        trackExamProgress();
    }
});
